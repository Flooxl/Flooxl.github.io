import { describe, it, expect } from 'vitest';
import { calculateAvailableBalance, validateWithdrawalAmount, formatCurrency } from '../utils/balanceUtils';
import { Transaction, Balance } from '../types';

describe('Balance Utilities', () => {
  describe('calculateAvailableBalance', () => {
    it('should correctly calculate balance from transactions', () => {
      const transactions: Transaction[] = [
        {
          id: '1',
          amount: 1000,
          type: 'quest_reward',
          status: 'completed',
          timestamp: new Date(),
          description: 'Quest completion reward'
        },
        {
          id: '2',
          amount: 500,
          type: 'withdrawal',
          status: 'completed',
          timestamp: new Date(),
          description: 'Withdrawal to bank'
        }
      ];

      expect(calculateAvailableBalance(transactions)).toBe(500);
    });

    it('should ignore pending transactions', () => {
      const transactions: Transaction[] = [
        {
          id: '1',
          amount: 1000,
          type: 'quest_reward',
          status: 'completed',
          timestamp: new Date(),
          description: 'Quest completion reward'
        },
        {
          id: '2',
          amount: 500,
          type: 'quest_reward',
          status: 'pending',
          timestamp: new Date(),
          description: 'Pending reward'
        }
      ];

      expect(calculateAvailableBalance(transactions)).toBe(1000);
    });
  });

  describe('validateWithdrawalAmount', () => {
    const balance: Balance = {
      total: 1000,
      pending: 0,
      available: 1000,
      currency: 'USD'
    };

    const method = {
      minAmount: 50,
      maxAmount: 1000
    };

    it('should validate valid withdrawal amount', () => {
      const result = validateWithdrawalAmount(500, balance, method);
      expect(result.isValid).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it('should reject negative amounts', () => {
      const result = validateWithdrawalAmount(-100, balance, method);
      expect(result.isValid).toBe(false);
      expect(result.error).toBe('Amount must be greater than 0');
    });

    it('should reject amounts exceeding available balance', () => {
      const result = validateWithdrawalAmount(1500, balance, method);
      expect(result.isValid).toBe(false);
      expect(result.error).toBe('Insufficient balance');
    });

    it('should reject amounts below minimum', () => {
      const result = validateWithdrawalAmount(20, balance, method);
      expect(result.isValid).toBe(false);
      expect(result.error).toBe('Minimum withdrawal amount is 50');
    });

    it('should reject amounts above maximum', () => {
      const result = validateWithdrawalAmount(1200, balance, method);
      expect(result.isValid).toBe(false);
      expect(result.error).toBe('Maximum withdrawal amount is 1000');
    });
  });

  describe('formatCurrency', () => {
    it('should format currency correctly', () => {
      expect(formatCurrency(1000)).toBe('$1,000.00');
      expect(formatCurrency(1000.5)).toBe('$1,000.50');
      expect(formatCurrency(0)).toBe('$0.00');
    });
  });
});