import React, { useState } from 'react';
import { Wallet, CreditCard, Ban as Bank, Bitcoin, AlertCircle } from 'lucide-react';
import { Balance, WithdrawalMethod, Transaction } from '../types';
import { validateWithdrawalAmount, formatCurrency } from '../utils/balanceUtils';

interface BalanceProps {
  balance: Balance;
  transactions: Transaction[];
  onWithdraw: (amount: number, method: WithdrawalMethod) => Promise<void>;
}

const withdrawalMethods: WithdrawalMethod[] = [
  {
    id: 'bank',
    type: 'bank',
    name: 'Bank Transfer',
    minAmount: 50,
    maxAmount: 10000,
    fee: 2.5,
    processingTime: '2-3 business days'
  },
  {
    id: 'paypal',
    type: 'bank',
    name: 'PayPal',
    minAmount: 20,
    maxAmount: 5000,
    fee: 1.5,
    processingTime: 'Instant'
  },
  {
    id: 'crypto',
    type: 'crypto',
    name: 'Cryptocurrency',
    minAmount: 100,
    maxAmount: 50000,
    fee: 1,
    processingTime: '1-2 hours'
  }
];

export function BalanceDisplay({ balance, transactions, onWithdraw }: BalanceProps) {
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<WithdrawalMethod>(withdrawalMethods[0]);
  const [amount, setAmount] = useState<string>('');
  const [error, setError] = useState<string>('');

  const handleWithdraw = async () => {
    const withdrawalAmount = parseFloat(amount);
    const validation = validateWithdrawalAmount(withdrawalAmount, balance, selectedMethod);
    
    if (!validation.isValid) {
      setError(validation.error || 'Invalid amount');
      return;
    }

    try {
      await onWithdraw(withdrawalAmount, selectedMethod);
      setIsWithdrawing(false);
      setAmount('');
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Withdrawal failed');
    }
  };

  return (
    <div className="quest-card p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold flex items-center gap-2">
          <Wallet className="w-6 h-6 text-neon-yellow" />
          Balance
        </h3>
        <button
          onClick={() => setIsWithdrawing(!isWithdrawing)}
          className="btn btn-secondary"
        >
          {isWithdrawing ? 'Cancel' : 'Withdraw'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-dark-bg p-4 rounded-lg">
          <p className="text-gray-400 text-sm">Available</p>
          <p className="text-2xl font-bold text-neon-yellow">
            {formatCurrency(balance.available)}
          </p>
        </div>
        <div className="bg-dark-bg p-4 rounded-lg">
          <p className="text-gray-400 text-sm">Pending</p>
          <p className="text-2xl font-bold">{formatCurrency(balance.pending)}</p>
        </div>
        <div className="bg-dark-bg p-4 rounded-lg">
          <p className="text-gray-400 text-sm">Total Earned</p>
          <p className="text-2xl font-bold">{formatCurrency(balance.total)}</p>
        </div>
      </div>

      {isWithdrawing && (
        <div className="space-y-4">
          <div className="border-t border-gray-800 pt-4">
            <h4 className="font-semibold mb-3">Withdrawal Method</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {withdrawalMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setSelectedMethod(method)}
                  className={`p-4 rounded-lg border ${
                    selectedMethod.id === method.id
                      ? 'border-neon-yellow bg-[rgba(228,255,0,0.1)]'
                      : 'border-gray-800 hover:border-gray-700'
                  } transition-colors`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    {method.type === 'bank' && <Bank className="w-5 h-5" />}
                    {method.type === 'crypto' && <Bitcoin className="w-5 h-5" />}
                    <span className="font-medium">{method.name}</span>
                  </div>
                  <p className="text-sm text-gray-400">
                    Fee: {method.fee}% • {method.processingTime}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <label className="block">
              <span className="text-sm font-medium text-gray-400">Amount</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="form-input mt-1"
                placeholder={`Min: ${formatCurrency(selectedMethod.minAmount)}`}
              />
            </label>

            {error && (
              <div className="flex items-center gap-2 text-red-500 text-sm">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}

            <div className="text-sm text-gray-400">
              <p>Minimum: {formatCurrency(selectedMethod.minAmount)}</p>
              <p>Maximum: {formatCurrency(selectedMethod.maxAmount)}</p>
              <p>Fee: {selectedMethod.fee}%</p>
            </div>

            <button
              onClick={handleWithdraw}
              className="btn btn-primary w-full"
              disabled={!amount || parseFloat(amount) <= 0}
            >
              Confirm Withdrawal
            </button>
          </div>
        </div>
      )}

      <div className="border-t border-gray-800 pt-4">
        <h4 className="font-semibold mb-3">Recent Transactions</h4>
        <div className="space-y-2">
          {transactions.slice(0, 5).map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between p-3 bg-dark-bg rounded-lg"
            >
              <div>
                <p className="font-medium">{transaction.description}</p>
                <p className="text-sm text-gray-400">
                  {transaction.timestamp.toLocaleDateString()}
                </p>
              </div>
              <p className={`font-medium ${
                transaction.type === 'withdrawal' ? 'text-red-500' : 'text-green-500'
              }`}>
                {transaction.type === 'withdrawal' ? '-' : '+'}
                {formatCurrency(transaction.amount)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}