import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Landing } from './pages/Landing';
import { BalanceDisplay } from './components/Balance';
import { useAuth } from './contexts/AuthContext';
import { Quest, Transaction, WithdrawalMethod } from './types';
import { 
  Sword, Shield, Target, Clock, DollarSign, Star, 
  Filter, Search, Bell, MessageSquare, User, Menu,
  Award, Briefcase, TrendingUp, Users, Trophy,
  CheckCircle, XCircle, AlertCircle, Calendar,
  Zap, Heart, Crown, Medal, X, Plus
} from 'lucide-react';
import { quests as initialQuests } from './data/quests';

function Dashboard() {
  const [activeTab, setActiveTab] = useState<'quests' | 'rankings' | 'profile'>('quests');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [quests, setQuests] = useState<Quest[]>(initialQuests);
  const [questFilter, setQuestFilter] = useState<'all' | 'available' | 'in-progress' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [balance, setBalance] = useState({
    total: 7500,
    pending: 2000,
    available: 5500,
    currency: 'USD'
  });

  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      amount: 5000,
      type: 'quest_reward',
      status: 'completed',
      timestamp: new Date(Date.now() - 86400000),
      description: 'Epic Anime Opening Sequence completion'
    },
    {
      id: '2',
      amount: 2500,
      type: 'quest_reward',
      status: 'completed',
      timestamp: new Date(Date.now() - 172800000),
      description: 'Gaming Highlight Reel completion'
    }
  ]);

  const handleWithdraw = async (amount: number, method: WithdrawalMethod) => {
    try {
      const newTransaction: Transaction = {
        id: Math.random().toString(36).substr(2, 9),
        amount,
        type: 'withdrawal',
        status: 'completed',
        timestamp: new Date(),
        description: `Withdrawal via ${method.name}`
      };

      setBalance(prev => ({
        ...prev,
        available: prev.available - amount,
        total: prev.total - amount
      }));

      setTransactions(prev => [newTransaction, ...prev]);
    } catch (error) {
      console.error('Withdrawal failed:', error);
      throw new Error('Withdrawal failed. Please try again.');
    }
  };

  const filteredQuests = quests.filter(quest => {
    if (questFilter !== 'all' && quest.status !== questFilter) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        quest.title.toLowerCase().includes(query) ||
        quest.description.toLowerCase().includes(query) ||
        quest.skills.some(skill => skill.toLowerCase().includes(query))
      );
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-dark-bg text-white flex flex-col">
      <header className="sticky top-0 z-40 bg-dark-bg border-b border-gray-800">
        <nav className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <h1 className="text-2xl font-bold text-neon-yellow flex items-center gap-2">
              <Shield className="w-6 h-6" />
              Request
            </h1>
            <div className="hidden md:flex items-center space-x-4">
              <button 
                onClick={() => setActiveTab('quests')}
                className={`nav-button ${activeTab === 'quests' ? 'active' : ''}`}
              >
                <Sword className="w-4 h-4 mr-2" />
                Quests
              </button>
              <button 
                onClick={() => setActiveTab('rankings')}
                className={`nav-button ${activeTab === 'rankings' ? 'active' : ''}`}
              >
                <Trophy className="w-4 h-4 mr-2" />
                Rankings
              </button>
              <button 
                onClick={() => setActiveTab('profile')}
                className={`nav-button ${activeTab === 'profile' ? 'active' : ''}`}
              >
                <User className="w-4 h-4 mr-2" />
                Profile
              </button>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="nav-button-primary">
              <Plus className="w-4 h-4 mr-2" />
              Post Quest
            </button>
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </nav>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        {activeTab === 'quests' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 md:items-center justify-between">
              <h2 className="text-2xl font-bold">Available Quests</h2>
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search quests..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-2 bg-dark-card rounded-lg border border-gray-800 focus:border-neon-yellow outline-none w-full md:w-64"
                  />
                </div>
                <select
                  value={questFilter}
                  onChange={(e) => setQuestFilter(e.target.value as any)}
                  className="px-4 py-2 bg-dark-card rounded-lg border border-gray-800 focus:border-neon-yellow outline-none"
                >
                  <option value="all">All Quests</option>
                  <option value="available">Available</option>
                  <option value="in-progress">In Progress</option>
                  <option value="completed">Completed</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredQuests.map(quest => (
                <div key={quest.id} className="quest-card">
                  <div className="p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <h3 className="text-xl font-bold">{quest.title}</h3>
                      <span className="px-3 py-1 rounded-full text-sm font-medium bg-[rgba(228,255,0,0.1)] text-neon-yellow">
                        ${quest.reward}
                      </span>
                    </div>
                    <p className="text-gray-400">{quest.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {quest.skills.map(skill => (
                        <span key={skill} className="skill-tag">
                          <Star className="w-4 h-4" />
                          {skill}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-400">
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {quest.timeframe}
                      </span>
                      <span className="flex items-center">
                        <Target className="w-4 h-4 mr-1" />
                        {quest.difficulty}
                      </span>
                    </div>
                    <button className="btn btn-primary w-full">
                      Accept Quest
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <BalanceDisplay
                balance={balance}
                transactions={transactions}
                onWithdraw={handleWithdraw}
              />
              <div className="quest-card p-6 space-y-6">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <Award className="w-6 h-6 text-neon-yellow" />
                  Statistics
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-dark-bg p-4 rounded-lg">
                    <p className="text-gray-400 text-sm">Completed Quests</p>
                    <p className="text-2xl font-bold">24</p>
                  </div>
                  <div className="bg-dark-bg p-4 rounded-lg">
                    <p className="text-gray-400 text-sm">Success Rate</p>
                    <p className="text-2xl font-bold">98%</p>
                  </div>
                  <div className="bg-dark-bg p-4 rounded-lg">
                    <p className="text-gray-400 text-sm">Total Earned</p>
                    <p className="text-2xl font-bold">$12,450</p>
                  </div>
                  <div className="bg-dark-bg p-4 rounded-lg">
                    <p className="text-gray-400 text-sm">Rank</p>
                    <p className="text-2xl font-bold text-rank-s">S</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'rankings' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Top Adventurers</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 9 }).map((_, index) => (
                <div key={index} className="quest-card p-6">
                  <div className="flex items-center gap-4">
                    <div className={`rank-badge rank-${index < 3 ? 's' : index < 6 ? 'a' : 'b'}`}>
                      {index + 1}
                    </div>
                    <div>
                      <h3 className="font-bold">Elite Editor {index + 1}</h3>
                      <p className="text-sm text-gray-400">Completed Quests: {30 - index * 2}</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-400">Success Rate</span>
                      <span className="text-neon-yellow">{100 - index * 2}%</span>
                    </div>
                    <div className="progress-bar">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${100 - index * 2}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;