import { Balance, Transaction } from '../types';

export function calculateAvailableBalance(transactions: Transaction[]): number {
  return transactions.reduce((total, transaction) => {
    if (transaction.status === 'completed') {
      switch (transaction.type) {
        case 'quest_reward':
          return total + transaction.amount;
        case 'withdrawal':
          return total - transaction.amount;
        case 'refund':
          return total + transaction.amount;
        default:
          return total;
      }
    }
    return total;
  }, 0);
}

export function validateWithdrawalAmount(amount: number, balance: Balance, method: { minAmount: number; maxAmount: number }): { isValid: boolean; error?: string } {
  if (amount <= 0) {
    return { isValid: false, error: 'Amount must be greater than 0' };
  }
  if (amount > balance.available) {
    return { isValid: false, error: 'Insufficient balance' };
  }
  if (amount < method.minAmount) {
    return { isValid: false, error: `Minimum withdrawal amount is ${method.minAmount}` };
  }
  if (amount > method.maxAmount) {
    return { isValid: false, error: `Maximum withdrawal amount is ${method.maxAmount}` };
  }
  return { isValid: true };
}

export function formatCurrency(amount: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(amount);
}