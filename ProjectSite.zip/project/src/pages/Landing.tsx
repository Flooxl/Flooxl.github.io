import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  Sword, Scroll, Shield, ArrowRight, Mail, Lock,
  Eye, EyeOff, CheckCircle, AlertCircle, User,
  Home
} from 'lucide-react';

type UserType = 'adventurer' | 'quest-giver' | null;
type AuthMode = 'login' | 'register';

interface FormData {
  email: string;
  password: string;
  username: string;
  confirmPassword: string;
}

const initialFormData: FormData = {
  email: '',
  password: '',
  username: '',
  confirmPassword: '',
};

export function Landing() {
  const navigate = useNavigate();
  const location = useLocation();
  const { signIn, signUp } = useAuth();
  
  const [selectedUserType, setSelectedUserType] = useState<UserType>(null);
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const validatePassword = (password: string): boolean => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    return (
      password.length >= minLength &&
      hasUpperCase &&
      hasLowerCase &&
      hasNumbers &&
      hasSpecialChar
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      if (authMode === 'register') {
        if (!selectedUserType) {
          throw new Error('Please select a user type');
        }

        if (formData.password !== formData.confirmPassword) {
          throw new Error('Passwords do not match');
        }

        if (!validatePassword(formData.password)) {
          throw new Error(
            'Password must be at least 8 characters long and contain uppercase, lowercase, numbers, and special characters'
          );
        }

        await signUp(formData.email, formData.password, selectedUserType, formData.username);
        // Show email verification message
        setError('Please check your email to verify your account');
      } else {
        await signIn(formData.email, formData.password);
        const from = (location.state as any)?.from?.pathname || '/dashboard';
        navigate(from, { replace: true });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const renderUserTypeSelection = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
      <button
        onClick={() => setSelectedUserType('adventurer')}
        className="user-type-card group"
      >
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-rank-s to-rank-a p-6 h-full">
          <div className="absolute inset-0 bg-dark-bg opacity-90 group-hover:opacity-80 transition-opacity"></div>
          <div className="relative z-10 space-y-4">
            <Sword className="w-12 h-12 text-neon-yellow" />
            <h3 className="text-2xl font-bold">Adventurer</h3>
            <p className="text-gray-300">
              Accept quests, showcase your skills, and earn rewards for your expertise.
              Join the ranks of elite editors and build your reputation.
            </p>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                Browse and accept diverse quests
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                Track your progress and earnings
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                Build your professional portfolio
              </li>
            </ul>
            <div className="flex items-center text-neon-yellow group-hover:translate-x-2 transition-transform">
              Get Started <ArrowRight className="w-5 h-5 ml-2" />
            </div>
          </div>
        </div>
      </button>

      <button
        onClick={() => setSelectedUserType('quest-giver')}
        className="user-type-card group"
      >
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-rank-b to-rank-c p-6 h-full">
          <div className="absolute inset-0 bg-dark-bg opacity-90 group-hover:opacity-80 transition-opacity"></div>
          <div className="relative z-10 space-y-4">
            <Scroll className="w-12 h-12 text-neon-yellow" />
            <h3 className="text-2xl font-bold">Quest Giver</h3>
            <p className="text-gray-300">
              Post editing quests, find talented editors, and get your content
              professionally edited by skilled adventurers.
            </p>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                Post custom editing quests
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                Review and select skilled editors
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                Manage projects efficiently
              </li>
            </ul>
            <div className="flex items-center text-neon-yellow group-hover:translate-x-2 transition-transform">
              Post Your First Quest <ArrowRight className="w-5 h-5 ml-2" />
            </div>
          </div>
        </div>
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-dark-bg text-white">
      <div className="container mx-auto px-4 py-12">
        {/* Skip Authentication Button */}
        <div className="absolute top-4 right-4">
          <Link
            to="/dashboard"
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-dark-card hover:bg-[#1a1a24] text-gray-300 hover:text-white transition-all"
          >
            <Home className="w-4 h-4" />
            <span>Skip Login</span>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-6">
            <Shield className="w-12 h-12 text-neon-yellow" />
            <h1 className="text-4xl md:text-5xl font-bold">Request</h1>
          </div>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            The ultimate marketplace connecting talented video editors with content creators.
            Choose your path and join our thriving community of professionals.
          </p>
        </div>

        {selectedUserType === null ? renderUserTypeSelection() : (
          <div className="max-w-md mx-auto">
            <div className="bg-dark-card rounded-xl p-6 shadow-lg border border-gray-800">
              {/* Form header */}
              <div className="flex items-center gap-2 mb-6">
                <button
                  onClick={() => setSelectedUserType(null)}
                  className="text-gray-400 hover:text-white"
                >
                  <ArrowRight className="w-5 h-5 rotate-180" />
                </button>
                <h2 className="text-xl font-bold">
                  {authMode === 'login' ? 'Welcome Back' : 'Join as'} {' '}
                  {selectedUserType === 'adventurer' ? 'Adventurer' : 'Quest Giver'}
                </h2>
              </div>

              {/* Auth mode toggle */}
              <div className="flex gap-2 mb-6">
                <button
                  onClick={() => {
                    setAuthMode('login');
                    setFormData(initialFormData);
                    setError('');
                  }}
                  className={`flex-1 py-2 rounded-lg transition-colors ${
                    authMode === 'login'
                      ? 'bg-neon-yellow text-dark-bg'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Login
                </button>
                <button
                  onClick={() => {
                    setAuthMode('register');
                    setFormData(initialFormData);
                    setError('');
                  }}
                  className={`flex-1 py-2 rounded-lg transition-colors ${
                    authMode === 'register'
                      ? 'bg-neon-yellow text-dark-bg'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Register
                </button>
              </div>

              {/* Auth form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                {authMode === 'register' && (
                  <div>
                    <label htmlFor="username" className="block text-sm font-medium text-gray-400 mb-1">
                      Username
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        id="username"
                        value={formData.username}
                        onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                        className="form-input pl-10"
                        placeholder="Choose a username"
                        required
                        minLength={3}
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      id="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="form-input pl-10"
                      placeholder="your@email.com"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-400 mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      id="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="form-input pl-10"
                      placeholder="••••••••"
                      required
                      minLength={8}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                    >
                      {showPassword ? (
                        <EyeOff className="w-5 h-5" />
                      ) : (
                        <Eye className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>

                {authMode === 'register' && (
                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-400 mb-1">
                      Confirm Password
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        id="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                        className="form-input pl-10"
                        placeholder="••••••••"
                        required
                      />
                    </div>
                  </div>
                )}

                {error && (
                  <div className="flex items-center gap-2 text-red-500 text-sm p-3 bg-red-500/10 rounded-lg">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <button 
                  type="submit" 
                  className="btn btn-primary w-full"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-dark-bg"></div>
                    </div>
                  ) : (
                    authMode === 'login' ? 'Login' : 'Create Account'
                  )}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}