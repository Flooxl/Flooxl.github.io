import { Quest } from '../types';

export const quests: Quest[] = [
  {
    id: '1',
    title: 'Epic Anime Opening Sequence',
    description: 'Create a legendary opening sequence for a major anime series. Incorporate dynamic transitions, special effects, and perfectly timed cuts to match the theme song.',
    reward: 5000,
    difficulty: 'expert',
    timeframe: '14 days',
    status: 'available',
    skills: ['After Effects', 'Sound Design', 'Color Grading'],
    client: 'Major Studio',
    requirements: ['Portfolio of previous anime work', '5+ years experience', 'Advanced After Effects knowledge'],
    category: 'animation'
  },
  {
    id: '2',
    title: 'Gaming Highlight Reel',
    description: 'Create an energetic montage of gaming highlights from provided footage. Focus on impactful moments and smooth transitions.',
    reward: 2000,
    difficulty: 'medium',
    timeframe: '7 days',
    status: 'available',
    skills: ['Premiere Pro', 'Motion Graphics'],
    client: 'ESports Team',
    requirements: ['Experience with gaming content', 'Strong sense of pacing'],
    category: 'editing'
  },
  {
    id: '3',
    title: 'Product Launch Video',
    description: 'Create a sleek and modern product reveal video for a new tech gadget. Emphasize product features through creative transitions and effects.',
    reward: 3000,
    difficulty: 'hard',
    timeframe: '10 days',
    status: 'available',
    skills: ['Cinema 4D', 'After Effects', 'Product Visualization'],
    client: 'Tech Startup',
    requirements: ['3D modeling experience', 'Product video portfolio'],
    category: 'animation'
  },
  // ... [Additional 17 quests with varying difficulties and requirements]
];