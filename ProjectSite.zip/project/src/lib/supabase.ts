import { createClient } from '@supabase/supabase-js';
import { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false
  }
});

export type Profile = Database['public']['Tables']['profiles']['Row'];

// Rate limiting configuration
const MAX_ATTEMPTS = 5;
const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes

export async function signUp(email: string, password: string, userType: 'adventurer' | 'quest-giver', username: string) {
  try {
    // Check if username already exists
    const { data: existingUser } = await supabase
      .from('profiles')
      .select('username')
      .eq('username', username)
      .single();

    if (existingUser) {
      throw new Error('Username already taken');
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          user_type: userType,
          username,
        },
        emailRedirectTo: `${window.location.origin}/auth/callback`
      }
    });

    if (error) throw error;
    
    return data;
  } catch (error) {
    console.error('Signup error:', error);
    throw error instanceof Error ? error : new Error('An error occurred during signup');
  }
}

export async function signIn(email: string, password: string) {
  try {
    // Check if user exists first
    const { data: userExists } = await supabase
      .from('profiles')
      .select('failed_attempts, locked_until')
      .eq('email', email)
      .maybeSingle();

    if (userExists?.locked_until && new Date(userExists.locked_until) > new Date()) {
      const timeLeft = Math.ceil((new Date(userExists.locked_until).getTime() - Date.now()) / 60000);
      throw new Error(`Account is temporarily locked. Please try again in ${timeLeft} minutes.`);
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      // Handle failed login attempt
      const newAttempts = (userExists?.failed_attempts || 0) + 1;
      const updates = {
        failed_attempts: newAttempts,
        locked_until: newAttempts >= MAX_ATTEMPTS 
          ? new Date(Date.now() + LOCKOUT_DURATION).toISOString()
          : null
      };

      await supabase
        .from('profiles')
        .update(updates)
        .eq('email', email);

      if (newAttempts >= MAX_ATTEMPTS) {
        throw new Error('Too many failed attempts. Account has been temporarily locked.');
      }

      throw new Error('Invalid email or password');
    }

    // Reset failed attempts on successful login
    if (userExists) {
      await supabase
        .from('profiles')
        .update({
          failed_attempts: 0,
          locked_until: null,
          last_login: new Date().toISOString(),
          login_count: (userExists.login_count || 0) + 1
        })
        .eq('email', email);
    }

    return data;
  } catch (error) {
    console.error('Login error:', error);
    throw error instanceof Error ? error : new Error('An error occurred during login');
  }
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function resetPassword(email: string) {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/reset-password`,
  });
  if (error) throw error;
}

export async function updatePassword(newPassword: string) {
  const { error } = await supabase.auth.updateUser({
    password: newPassword,
  });
  if (error) throw error;
}