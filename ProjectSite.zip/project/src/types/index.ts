// Type definitions for the application
export interface Quest {
  id: string;
  title: string;
  description: string;
  reward: number;
  difficulty: 'beginner' | 'easy' | 'medium' | 'hard' | 'expert';
  timeframe: string;
  status: 'available' | 'in-progress' | 'completed' | 'expired';
  skills: string[];
  client: string;
  deadline?: Date;
  acceptedAt?: Date;
  completedAt?: Date;
  requirements: string[];
  category: 'editing' | 'animation' | 'vfx' | 'color' | 'sound';
}

export interface Balance {
  total: number;
  pending: number;
  available: number;
  currency: string;
}

export interface Transaction {
  id: string;
  amount: number;
  type: 'quest_reward' | 'withdrawal' | 'refund';
  status: 'pending' | 'completed' | 'failed';
  timestamp: Date;
  questId?: string;
  description: string;
}

export interface WithdrawalMethod {
  id: string;
  type: 'bank' | 'paypal' | 'crypto';
  name: string;
  minAmount: number;
  maxAmount: number;
  fee: number;
  processingTime: string;
}